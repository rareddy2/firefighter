### Simulator

#### Terminal 1
Switch to your catkin directory  
$ source devel/setup.bash  
$ roslaunch ur3_driver ur3_gazebo.launch  

#### Terminal 2
Switch to your catkin directory  
$ source devel/setup.bash  
$ rosrun lab4pkg_py lab4_exec.py 0.1 0.1 0.15 90  

### Real Robot

#### Terminal 1
Switch to your catkin directory  
$ source devel/setup.bash  
$ roslaunch ur3_driver ur3_driver.launch  

#### Terminal 2
Switch to your catkin directory  
$ source devel/setup.bash  
$ rosrun lab4pkg_py lab4_exec.py 0.1 0.1 0.15 90  
